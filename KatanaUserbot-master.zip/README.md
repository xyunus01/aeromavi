
<div align="center">
  <img src="https://i.hizliresim.com/9zgq9dj.jpg" width="300" height="300">
  <h1> Teloid UserBot </h1>
</div>

----
## Kurulum/Setup
 
[![Run on Repl.it](https://replit.com/badge/github/ber4tbey/lavanstax)](https://replit.com/@ByMisakiMey/teloiduserbot)


## Bilgilendirme / İnformation 
***Herhangi bir istek & şikayet & öneriniz varsa [Destek Grubuna](https://t.me/robotgersupport) ulaşabilirsiniz.***

***You can reach the [Support group](https://t.me/robotgersupport) if there are any requests & complaints & suggestions.***
```
    Userbottan dolayı; Telegram hesabınız yasaklanabilir.
    Bu bir açık kaynaklı projedir, yaptığınız her işlemden kendiniz sorumlusunuz. Kesinlikle Robotger yöneticileri sorumluluk kabul etmemektedir.
    Teloid Userbot kurarak bu sorumlulukları kabul etmiş sayılırsınız.
```

```
    Due to Userbot; Your Telegram account may be banned.
    This is an open source project, you are responsible for everything you do. Absolutely, Robotger administrators do not accept responsibility.
    By establishing Teloid Userbot, you are deemed to have accepted these responsibilities.
```

### Geliştiriciler / Developers
  [![ErdemBey](https://github.com/Erdewbey.png?size=100)](https://github.com/erdewbey)
 [![Misaki](https://github.com/ber4tbey.png?size=100)](https://github.com/ber4tbey) 

## Credit
Thanks for;

[Seden UserBot](https://github.com/TeamDerUntergang/Telegram-UserBot)

[Userge](https://github.com/UsergeTeam/Userge)

[Spechide](https://github.com/Spechide)

[Asena](https://github.com/yusufusta/asenauserbot)

